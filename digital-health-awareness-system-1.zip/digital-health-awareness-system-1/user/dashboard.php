<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">User Dashboard</h1>
        <div>
            <a href="../index.php" class="btn btn-outline-primary me-2"><i class="bi bi-house me-1"></i> Home</a>
            <a href="../logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <p>Welcome <?php echo $_SESSION['fullname']; ?></p>
</div>

</body>
</html>