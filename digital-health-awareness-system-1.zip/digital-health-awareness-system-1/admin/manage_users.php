<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

include '../config/database.php';

/* Delete User */
if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query($conn, "DELETE FROM users WHERE id=$id");

    header("Location: manage_users.php");
    exit();
}

$result = mysqli_query(
    $conn,
    "SELECT * FROM users ORDER BY created_at DESC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <h2>Manage Users</h2>

    <table class="table table-bordered">

        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Registered</th>
            <th>Action</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)){ ?>

        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['fullname']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['role']; ?></td>
            <td><?php echo $row['created_at']; ?></td>

            <td>
                <a href="?delete=<?php echo $row['id']; ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this user?')">
                   Delete
                </a>
            </td>
        </tr>

        <?php } ?>

    </table>

    <a href="dashboard.php" class="btn btn-secondary">
        Back to Dashboard
    </a>

</div>

</body>
</html>