<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

include '../config/database.php';

if(isset($_POST['add_article'])){

    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);

    mysqli_query(
        $conn,
        "INSERT INTO articles(title, category, content)
         VALUES('$title','$category','$content')"
    );
}
if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query($conn, "DELETE FROM articles WHERE id=$id");

    header("Location: manage_articles.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Articles</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Manage Health Articles</h2>
        <a href="dashboard.php" class="btn btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <form method="POST">

        <div class="mb-3">
            <label>Article Title</label>
            <input type="text"
                   name="title"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <input type="text"
                   name="category"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label>Content</label>
            <textarea name="content"
                      class="form-control"
                      rows="5"
                      required></textarea>
        </div>

        <button type="submit"
                name="add_article"
                class="btn btn-success">
            Add Article
        </button>

    </form>

    <hr>

    <h3>Existing Articles</h3>

    <table class="table table-bordered">

        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Date</th>
            <th>Action</th>
        </tr>

        <?php

        $result = mysqli_query(
            $conn,
            "SELECT * FROM articles ORDER BY id DESC"
        );

        while($row = mysqli_fetch_assoc($result)){
        ?>

        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['created_at']; ?></td>
            <td>
                <a href="manage_articles.php?delete=<?php echo $row['id']; ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this article?')">
                    Delete
                </a>
            </td>
        </tr>

        <?php } ?>

    </table>

</div>

</body>
</html>