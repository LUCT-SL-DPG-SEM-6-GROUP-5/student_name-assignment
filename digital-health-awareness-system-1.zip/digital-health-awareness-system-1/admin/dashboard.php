<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

include '../config/database.php';

$user_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users"));
$article_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM articles"));
$alert_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM alerts"));
$feedback_count = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM feedback"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <h1 class="mb-4">
        Welcome, <?php echo $_SESSION['fullname']; ?>
    </h1>

    <div class="row">

        <div class="col-md-3">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h2><?php echo $user_count; ?></h2>
                    <p>Total Users</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h2><?php echo $article_count; ?></h2>
                    <p>Articles</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h2><?php echo $alert_count; ?></h2>
                    <p>Health Alerts</p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow text-center">
                <div class="card-body">
                    <h2><?php echo $feedback_count; ?></h2>
                    <p>Feedback</p>
                </div>
            </div>
        </div>

    </div>

    <div class="mt-4">
        <a href="manage_articles.php" class="btn btn-success">Manage Articles</a>
        <a href="manage_alerts.php" class="btn btn-warning">Manage Alerts</a>
        <a href="manage_users.php" class="btn btn-primary">Manage Users</a>
        <a href="view_feedback.php" class="btn btn-info">View Feedback</a>
        <a href="../index.php" class="btn btn-outline-primary ms-2"><i class="bi bi-box-arrow-up-right me-1"></i> Visit Site</a>
        <a href="../logout.php" class="btn btn-danger">Logout</a>
    </div>

</div>

</body>
</html>