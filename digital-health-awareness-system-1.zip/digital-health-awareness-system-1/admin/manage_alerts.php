<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

include '../config/database.php';

/* Add Alert */
if(isset($_POST['add_alert'])){

    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    mysqli_query(
        $conn,
        "INSERT INTO alerts(title, message)
         VALUES('$title','$message')"
    );
}

/* Delete Alert */
if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query($conn, "DELETE FROM alerts WHERE id=$id");

    header("Location: manage_alerts.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Health Alerts</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <h2>Manage Health Alerts</h2>

    <form method="POST">

        <div class="mb-3">
            <label class="form-label">Alert Title</label>
            <input type="text"
                   name="title"
                   class="form-control"
                   required>
        </div>

        <div class="mb-3">
            <label class="form-label">Alert Message</label>
            <textarea name="message"
                      class="form-control"
                      rows="4"
                      required></textarea>
        </div>

        <button type="submit"
                name="add_alert"
                class="btn btn-warning">
            Add Alert
        </button>

    </form>

    <hr>

    <h3>Existing Alerts</h3>

    <table class="table table-bordered">

        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Message</th>
            <th>Date</th>
            <th>Action</th>
        </tr>

        <?php

        $result = mysqli_query(
            $conn,
            "SELECT * FROM alerts ORDER BY id DESC"
        );

        while($row = mysqli_fetch_assoc($result)){
        ?>

        <tr>

            <td><?php echo $row['id']; ?></td>

            <td><?php echo $row['title']; ?></td>

            <td><?php echo $row['message']; ?></td>

            <td><?php echo $row['created_at']; ?></td>

            <td>
                <a href="?delete=<?php echo $row['id']; ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this alert?')">
                    Delete
                </a>
            </td>

        </tr>

        <?php } ?>

    </table>

    <a href="dashboard.php" class="btn btn-secondary">
        Back to Dashboard
    </a>

</div>

</body>
</html>